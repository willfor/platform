package util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MantisConstant {
	public static String MANTIS_URL = "http://mantis.ucweb.local/api/open_api.php";
	
	public static String newBUG = "10";// 新建
	public static String dahui = "20";// 打回
	public static String fixed = "80";// 重新打开
	public static String closed = "90";// 已关闭
	public static String reOpen = "25";// 重新打开
	public static String establish = "30";// 公认
	public static String affirm = "40";// 已确认
	public static String assign = "50";// 已分派
	public static String solve = "80";// 已解决
	public static String watch = "85";// 观察
	
	public static String REPORTER = "luyy3";
	public static String HANDLER = "fengzq3";
	
	public static String ENCODE_UTF8 = "utf-8";
	public static String REPRODUCIBILITY = "50";// 出现概率
	public static String TREAT_IDEA = "30";// 处理意见
	public static String SEVERITY = "70";// 严重性
	
	

	
}
