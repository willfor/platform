package controllers;

import play.mvc.Controller;

public class Application extends Controller {

    public static void index() {
    	
        render();
    }
    
    public static void pack(){
    	
    	render();
    }
    
    public static void pack_desc(){
    	
    	render();
    }
    
    public static void report_display(){
    	render();
    }
    
    public static void branch_management(){
    	render();
    }
    
    public static void platform_readme(){
    	render();
    }
    
  
    
    

}